
## 1.3.6

- NC27 support
## 1.3.5

- Fix issue on external storage
## 1.3.4

- NC24 support
## 1.3.3

- NC23 support
## 1.3.2

- NC22 support
## 1.3.1

- NC21 support

## 1.3.0

- Better handling of files
- Improved performances
- Support group folders
- Support all external storage methods

## 1.2.5

- Update to NC 20

## 1.2.4

- Update to NC 19
- Add debug infos
- Remove accidently shipped phpunit

## 1.2.3

- Update to NC 18
- Fix security issues

## 1.2.2

- Update to NC 17
- Fix languages
- Fix shared folders
- Fix rar folder scan

## 1.2.1

- Add languages

## 1.2.0

- Tar, Gzip, 7z, Deb and Bzip2 support
- Add error messages
- Fix security issue
- Fix shared files issue
- Others minor fixes

## 1.1.1

- Improved external storage reliability

## 1.0.0

- Rar support
- Loading icon
- Fix icon issue

## 1.1.0

- Bug fixes

## 0.0.4

- Bug fixes on firefox

## 0.0.3

- Bug fixes

## 0.0.2

- Bug fixes

## 0.0.1

- Zip support
