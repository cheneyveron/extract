OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Şifrələmə dəstəklənmir",
    "Zip extension is not available" : "Zip ekstrakt mövcud deyil",
    "Cannot open Zip file" : "Zip faylı ammaq olmur",
    "Extract" : "Ekstrakt et",
    "Extract archive from the web interface" : "Arxivi veb interfeysdən ekstrakt edin",
    "Extract here" : "Bura ekstrakt edin"
},
"nplurals=2; plural=(n != 1);");
