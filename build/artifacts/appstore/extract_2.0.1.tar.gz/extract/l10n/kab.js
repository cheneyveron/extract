OC.L10N.register(
    "extract",
    {
    "File not found" : "Ulac afaylu"
},
"nplurals=2; plural=(n != 1);");
