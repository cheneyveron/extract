OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Šifriranje še ni podprto",
    "File not found" : "Datoteke ni mogoče najti",
    "Zip extension is not available" : "Razširitev zip ni na voljo",
    "Cannot open Zip file" : "Datoteke zip ni mogoče odpreti",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Ojoj, prišlo je do napake. Preverite, da je nameščena razširitev rar ali unrar.",
    "Extract" : "Razširi",
    "Extract archive from the web interface" : "Razširjanje vsebine arhiva prek spletnega vmesnika",
    "Extract here" : "Razširi na to mesto"
},
"nplurals=4; plural=(n%100==1 ? 0 : n%100==2 ? 1 : n%100==3 || n%100==4 ? 2 : 3);");
