OC.L10N.register(
    "extract",
    {
    "File not found" : "Fann ikkje fila"
},
"nplurals=2; plural=(n != 1);");
