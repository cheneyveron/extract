OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Lo chiframent es pas encara pres en carga",
    "File not found" : "Fichièr pas trobat",
    "Zip extension is not available" : "extension Zip pas disponibla",
    "Cannot open Zip file" : "Dubertura de fichièr Zip impossibla",
    "Extract" : "Traire",
    "Extract here" : "Traire aquí"
},
"nplurals=2; plural=(n > 1);");
