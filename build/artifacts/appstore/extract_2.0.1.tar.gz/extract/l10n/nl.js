OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Versleuteling is nog niet ondersteund",
    "File not found" : "Bestand niet gevonden",
    "Zip extension is not available" : "Zip-extensie niet beschikbaar",
    "Cannot open Zip file" : "Kan zip-bestand niet openen",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Oeps! Er is iets misgegaan. Controleer of je de rar-extensie of unrar hebt geïnstalleerd",
    "Extract" : "Uitpakken",
    "Extract archive from the web interface" : "Archief uitpakken vanuit de webinterface",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "Archieven uitpakken.\n\n*  **Ondersteund:**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Vereisten:**\n    * Rar PHP-extensie (pecl -v install rar)\n\n    * **OF**\n    * unrar (sudo apt-get install unrar)\n\n    * **EN**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Opmerking:** Versleutelde bestanden worden nog niet ondersteund",
    "Extract here" : "Hier uitpakken"
},
"nplurals=2; plural=(n != 1);");
