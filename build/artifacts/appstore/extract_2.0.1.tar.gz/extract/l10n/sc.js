OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Tzifradura ancora non suportada",
    "File not found" : "Archìviu no agatadu",
    "Zip extension is not available" : "S'estensione zip no est a disponimentu ",
    "Cannot open Zip file" : "No faghet a abèrrere s'archìviu Zip",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Oops calicuna cosa est andada male. Controlla chi tèngias is estensiones rar o unrar installadas",
    "Extract" : "Boga a fora",
    "Extract archive from the web interface" : "Boga a fora s'archìviu dae s'interfache ìnternet",
    "Extract here" : "Boga a fora inoghe"
},
"nplurals=2; plural=(n != 1);");
