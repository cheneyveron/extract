OC.L10N.register(
    "extract",
    {
    "File not found" : "Fayl topilmadi"
},
"nplurals=1; plural=0;");
