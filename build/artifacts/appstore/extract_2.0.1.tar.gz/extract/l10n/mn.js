OC.L10N.register(
    "extract",
    {
    "File not found" : "Файл олдсонгүй"
},
"nplurals=2; plural=(n != 1);");
