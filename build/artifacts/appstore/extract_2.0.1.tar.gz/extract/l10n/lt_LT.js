OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Kol kas šifravimas nepalaikomas",
    "File not found" : "Failas nerastas",
    "Cannot open Zip file" : "Nepavyksta atverti Zip failo",
    "Extract" : "Išskleisti",
    "Extract archive from the web interface" : "Išskleisti archyvą iš saityno sąsajos",
    "Extract here" : "Išskleisti čia"
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
