OC.L10N.register(
    "extract",
    {
    "File not found" : "ไม่พบไฟล์"
},
"nplurals=1; plural=0;");
