OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Все още не се поддържа kриптиране",
    "File not found" : "Файлът не е намерен",
    "Zip extension is not available" : "Разширението Zip не е налично",
    "Cannot open Zip file" : "Zip файлът не може да се отвори ",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Опа, нещо се обърка. Проверете дали имате инсталирано разширение rar или unrar",
    "Extract" : "Извличане",
    "Extract archive from the web interface" : "Извличане на архив от уеб интерфейса",
    "Extract here" : "Извличане тук"
},
"nplurals=2; plural=(n != 1);");
