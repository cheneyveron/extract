OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Η κρυπτογράφηση δεν υποστηρίζεται ακόμη",
    "File not found" : "Δε βρέθηκε το αρχείο",
    "Zip extension is not available" : "Η επέκταση zip δεν είναι διαθέσιμη",
    "Cannot open Zip file" : "Αδυναμία ανοίγματος αρχείου Zip",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Ωχ! Κάτι πήγε στραβά. Βεβαιωθείτε ότι έχετε εγκαταστήσει την επέκταση rar ή unrar",
    "Extract" : "Αποσυμπίεση",
    "Extract archive from the web interface" : "Αποσυμπίεση αρχείου από περιηγητή",
    "Extract here" : "Εξαγωγή εδώ"
},
"nplurals=2; plural=(n != 1);");
