OC.L10N.register(
    "extract",
    {
    "File not found" : "Ficheiro não encontrado",
    "Zip extension is not available" : "Não está disponível a extração de ficheiros  com a extensão ZIP",
    "Extract" : "Extrair",
    "Extract archive from the web interface" : "Extrair o ficheiro desde a interface WEB",
    "Extract here" : "Extrair aqui"
},
"nplurals=3; plural=(n == 0 || n == 1) ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
