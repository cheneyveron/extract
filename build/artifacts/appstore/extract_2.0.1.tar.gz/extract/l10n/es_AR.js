OC.L10N.register(
    "extract",
    {
    "File not found" : "Archivo no encontrado"
},
"nplurals=3; plural=n == 1 ? 0 : n != 0 && n % 1000000 == 0 ? 1 : 2;");
