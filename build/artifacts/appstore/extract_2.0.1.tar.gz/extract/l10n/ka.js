OC.L10N.register(
    "extract",
    {
    "File not found" : "File not found"
},
"nplurals=2; plural=(n!=1);");
