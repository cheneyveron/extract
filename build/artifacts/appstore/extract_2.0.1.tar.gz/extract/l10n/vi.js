OC.L10N.register(
    "extract",
    {
    "File not found" : "Không tìm thấy tập tin"
},
"nplurals=1; plural=0;");
