OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "尚不支持加密",
    "File not found" : "文件未找到",
    "Zip extension is not available" : "Zip 扩展不可用",
    "Cannot open Zip file" : "打不开 Zip 文件",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "哎呀，出问题了。请检查您是否安装了 rar 扩展或 unrar。",
    "Extract" : "解压",
    "Extract archive from the web interface" : "从网页界面解压压缩包",
    "Extract here" : "解压到这里"
},
"nplurals=1; plural=0;");
