OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "עדיין אין תמיכה בהצפנה",
    "File not found" : "קובץ לא נמצא",
    "Zip extension is not available" : "הסיומת Zip אינה זמינה",
    "Cannot open Zip file" : "לא ניתן לפתוח קובץ Zip",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "אופס, משהו השתבש. נא לוודא שיש לך סיומת rar או את unrar מותקן",
    "Extract" : "חילוץ",
    "Extract archive from the web interface" : "חילוץ ארכיון בעזרת מנשק הדפדפן",
    "Extract here" : "לחלץ לכאן"
},
"nplurals=3; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: 2;");
