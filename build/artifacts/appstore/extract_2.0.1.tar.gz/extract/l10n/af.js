OC.L10N.register(
    "extract",
    {
    "File not found" : "Lêer nie gevind nie"
},
"nplurals=2; plural=(n != 1);");
