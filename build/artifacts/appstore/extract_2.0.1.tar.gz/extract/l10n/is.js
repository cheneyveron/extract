OC.L10N.register(
    "extract",
    {
    "File not found" : "Skrá finnst ekki",
    "Zip extension is not available" : "Zip-viðaukinn er ekki tiltækur",
    "Extract" : "Afþjappa",
    "Extract archive from the web interface" : "Afþjappa safnskrá úr vefviðmótinu",
    "Extract here" : "Afþjappa hér"
},
"nplurals=2; plural=(n % 10 != 1 || n % 100 == 11);");
