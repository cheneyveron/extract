OC.L10N.register(
    "extract",
    {
    "File not found" : "Նիշքը չգտնվեց"
},
"nplurals=2; plural=(n != 1);");
