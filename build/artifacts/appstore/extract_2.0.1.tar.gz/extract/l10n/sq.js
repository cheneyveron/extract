OC.L10N.register(
    "extract",
    {
    "File not found" : "S’u gjet kartelë"
},
"nplurals=2; plural=(n != 1);");
