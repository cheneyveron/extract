OC.L10N.register(
    "extract",
    {
    "File not found" : "Datne nav atrasta"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
