OC.L10N.register(
    "extract",
    {
    "File not found" : "Faýl tapylmady"
},
"nplurals=2; plural=(n != 1);");
