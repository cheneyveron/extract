OC.L10N.register(
    "extract",
    {
    "File not found" : "ფაილი ვერ იქნა ნაპოვნი"
},
"nplurals=2; plural=(n!=1);");
