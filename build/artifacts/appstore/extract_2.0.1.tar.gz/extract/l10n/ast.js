OC.L10N.register(
    "extract",
    {
    "File not found" : "Nun s'atopó'l ficheru"
},
"nplurals=2; plural=(n != 1);");
