OC.L10N.register(
    "extract",
    {
    "File not found" : "Netrovita dosiero"
},
"nplurals=2; plural=(n != 1);");
