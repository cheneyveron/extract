OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "El xifratge encara no és permès",
    "File not found" : "No s'ha trobat el fitxer",
    "Zip extension is not available" : "L'extensió zip no està disponible",
    "Cannot open Zip file" : "No es pot obrir el fitxer ZIP",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Alguna cosa ha anat malament. Comproveu que teniu la extensió rar o unrar instal·lada",
    "Extract" : "Extreure",
    "Extract archive from the web interface" : "Extreure l'arxiu de la interfície web",
    "Extract here" : "Extreure aquí"
},
"nplurals=2; plural=(n != 1);");
