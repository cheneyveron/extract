OC.L10N.register(
    "extract",
    {
    "File not found" : "ಕಡತ ಕಂಡುಬಂದಿಲ್ಲ"
},
"nplurals=2; plural=(n > 1);");
