OC.L10N.register(
    "extract",
    {
    "File not found" : "ফাইল খুঁজে পাওয়া গেল না"
},
"nplurals=2; plural=(n != 1);");
