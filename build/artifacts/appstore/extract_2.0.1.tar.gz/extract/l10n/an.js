OC.L10N.register(
    "extract",
    {
    "File not found" : "Fichero no trobau"
},
"nplurals=2; plural=(n != 1);");
