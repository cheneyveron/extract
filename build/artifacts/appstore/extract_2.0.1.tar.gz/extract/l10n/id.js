OC.L10N.register(
    "extract",
    {
    "File not found" : "Berkas tidak ditemukan"
},
"nplurals=1; plural=0;");
