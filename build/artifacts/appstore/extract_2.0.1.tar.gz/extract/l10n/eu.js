OC.L10N.register(
    "extract",
    {
    "Encryption is not supported yet" : "Oraindik ez da enkriptatzea onartzen",
    "File not found" : "Ez da fitxategia aurkitu",
    "Zip extension is not available" : "Zip hedapena ez dago eskuragarri",
    "Cannot open Zip file" : "Ezin da Zip fitxategia ireki",
    "Oops something went wrong. Check that you have rar extension or unrar installed" : "Arazoren bat izan da. Egiaztatu rar luzapena edo unrar instalatuta duzula",
    "Extract" : "Atera",
    "Extract archive from the web interface" : "Atera artxiboa web interfazetik",
    "Extract archives.\n\n*  **Supported :**\n\n    * Zip\n    * Rar\n    * Tar\n    * Gzip\n    * 7z\n    * Deb\n    * Bzip2\n\n*  **Requirements :**\n    * Rar PHP extension  (pecl -v install rar)\n\n    * **OR**\n    * unrar (sudo apt-get install unrar)\n\n    * **AND**\n    * p7zip (sudo apt-get install p7zip p7zip-full)\n\n*  **Note :** Encrypted files are not supported yet" : "Atera artxiboak.\n\n* **Onartzen du :**\n\n* Zip\n* Arraroa\n* Tar\n* Gzip\n* 7z\n* Deb\n* Bzip2\n\n* **Baldintzak:**\n* Rar PHP luzapena (pecl -v install rar)\n\n* **EDO**\n* unrar (sudo apt-get install unrar)\n\n* **ETA**\n* p7zip (sudo apt-get install p7zip p7zip-full)\n\n* **Oharra :** Zifratutako fitxategiak ez dira onartzen oraindik",
    "Extract here" : "Atera hemen"
},
"nplurals=2; plural=(n != 1);");
